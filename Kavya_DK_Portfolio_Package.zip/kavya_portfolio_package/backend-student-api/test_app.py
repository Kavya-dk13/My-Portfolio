import pytest
from app import app, initialize_database

@pytest.fixture()
def client(tmp_path, monkeypatch):
    import app as api
    monkeypatch.setattr(api, "DATABASE", tmp_path / "test.sqlite3")
    api.app.config.update(TESTING=True)
    api.initialize_database()
    with api.app.test_client() as client:
        yield client

def test_health(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json["status"] == "ok"

def test_student_crud(client):
    created = client.post("/api/students", json={
        "name": "Asha Rao", "email": "asha@example.com", "course": "Python"
    })
    assert created.status_code == 201
    student_id = created.json["id"]
    assert client.get(f"/api/students/{student_id}").status_code == 200
    updated = client.put(f"/api/students/{student_id}", json={
        "name": "Asha R", "email": "asha@example.com", "course": "Backend"
    })
    assert updated.status_code == 200
    assert updated.json["course"] == "Backend"
    assert client.delete(f"/api/students/{student_id}").status_code == 200
    assert client.get(f"/api/students/{student_id}").status_code == 404

def test_validation(client):
    response = client.post("/api/students", json={"name": "Incomplete"})
    assert response.status_code == 400
