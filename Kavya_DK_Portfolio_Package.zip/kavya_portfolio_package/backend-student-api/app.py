"""Student Records REST API — portfolio learning project.

Run:
    python -m venv .venv
    # activate the environment
    pip install -r requirements.txt
    python app.py
"""
from __future__ import annotations
import logging
import os
import sqlite3
import time
from pathlib import Path
from flask import Flask, g, jsonify, request

BASE_DIR = Path(__file__).resolve().parent
DATABASE = Path(os.environ.get("STUDENT_API_DB", BASE_DIR / "students.db"))

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("student-api")


# Middleware: record request method, path, status and processing time.
@app.before_request
def start_request_timer():
    g.request_started_at = time.perf_counter()


@app.after_request
def log_request(response):
    started = getattr(g, "request_started_at", None)
    elapsed_ms = (time.perf_counter() - started) * 1000 if started else 0
    logger.info("%s %s -> %s (%.2f ms)", request.method, request.path,
                response.status_code, elapsed_ms)
    response.headers["X-Process-Time-ms"] = f"{elapsed_ms:.2f}"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def initialize_database():
    DATABASE.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DATABASE) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                course TEXT NOT NULL
            )
        """)


def error(message, status):
    return jsonify({"error": message}), status


def validate_student(payload):
    if not isinstance(payload, dict):
        return None, "Request body must be a JSON object."
    required = ("name", "email", "course")
    cleaned = {key: str(payload.get(key, "")).strip() for key in required}
    missing = [key for key, value in cleaned.items() if not value]
    if missing:
        return None, "Required fields: " + ", ".join(missing)
    if "@" not in cleaned["email"] or "." not in cleaned["email"].split("@")[-1]:
        return None, "Please provide a valid email address."
    return cleaned, None


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "student-records-api"})


@app.get("/api/students")
def list_students():
    rows = get_db().execute(
        "SELECT id, name, email, course FROM students ORDER BY id"
    ).fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/students/<int:student_id>")
def get_student(student_id):
    row = get_db().execute(
        "SELECT id, name, email, course FROM students WHERE id = ?", (student_id,)
    ).fetchone()
    if row is None:
        return error("Student not found.", 404)
    return jsonify(dict(row))


@app.post("/api/students")
def create_student():
    payload, problem = validate_student(request.get_json(silent=True))
    if problem:
        return error(problem, 400)
    try:
        db = get_db()
        cursor = db.execute(
            "INSERT INTO students (name, email, course) VALUES (?, ?, ?)",
            (payload["name"], payload["email"], payload["course"]),
        )
        db.commit()
        row = db.execute(
            "SELECT id, name, email, course FROM students WHERE id = ?",
            (cursor.lastrowid,),
        ).fetchone()
        return jsonify(dict(row)), 201
    except sqlite3.IntegrityError:
        return error("A student with this email already exists.", 409)


@app.put("/api/students/<int:student_id>")
def update_student(student_id):
    payload, problem = validate_student(request.get_json(silent=True))
    if problem:
        return error(problem, 400)
    db = get_db()
    exists = db.execute("SELECT id FROM students WHERE id = ?", (student_id,)).fetchone()
    if exists is None:
        return error("Student not found.", 404)
    try:
        db.execute(
            "UPDATE students SET name = ?, email = ?, course = ? WHERE id = ?",
            (payload["name"], payload["email"], payload["course"], student_id),
        )
        db.commit()
        row = db.execute(
            "SELECT id, name, email, course FROM students WHERE id = ?", (student_id,)
        ).fetchone()
        return jsonify(dict(row))
    except sqlite3.IntegrityError:
        return error("A student with this email already exists.", 409)


@app.delete("/api/students/<int:student_id>")
def delete_student(student_id):
    db = get_db()
    cursor = db.execute("DELETE FROM students WHERE id = ?", (student_id,))
    db.commit()
    if cursor.rowcount == 0:
        return error("Student not found.", 404)
    return jsonify({"message": "Student deleted successfully."})


@app.errorhandler(404)
def not_found(_exc):
    return error("Route not found.", 404)


@app.errorhandler(405)
def method_not_allowed(_exc):
    return error("HTTP method not allowed for this route.", 405)


@app.errorhandler(500)
def internal_error(_exc):
    logger.exception("Unhandled server error")
    return error("Internal server error.", 500)


initialize_database()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
