# Student Records REST API — Backend & Middleware Demo

A portfolio learning project demonstrating Python backend fundamentals. This is a personal demo project, not employment experience.

## Stack
- Python 3
- Flask (HTTP routes and JSON responses)
- SQLite (relational persistence)
- Flask request lifecycle hooks (`before_request`, `after_request`) for simple middleware
- Pytest (automated API tests)

## Features
- Health endpoint
- Create, list, read, update and delete student records
- Required-field and email-format validation
- Duplicate-email conflict handling
- Consistent JSON error responses
- Request method/path/status and elapsed-time logging
- Response headers for processing time and content-type protection

## Run locally
```bash
cd backend-student-api
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
The API starts at `http://127.0.0.1:5000`.

## Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/students` | List students |
| GET | `/api/students/1` | Get one student |
| POST | `/api/students` | Create student |
| PUT | `/api/students/1` | Update student |
| DELETE | `/api/students/1` | Delete student |

### Example POST body
```json
{
  "name": "Asha Rao",
  "email": "asha@example.com",
  "course": "Python Backend"
}
```

## Run tests
```bash
pytest -q
```

## Middleware explanation for interviews
The `before_request` hook records the request start time. The `after_request` hook logs the HTTP method, path, response status and processing time, then adds an `X-Process-Time-ms` response header. This demonstrates request/response middleware behavior in Flask.

## Next improvements
Authentication and role-based access, pagination, database migrations, structured logging, API documentation, rate limiting and deployment behind a production WSGI server.
