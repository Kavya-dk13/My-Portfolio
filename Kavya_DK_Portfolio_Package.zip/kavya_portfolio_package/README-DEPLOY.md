# Publish Kavya DK's portfolio

## What is included
- `index.html` and `profile.jpg`: static portfolio website
- `Kavya_DK_Resume.pdf`: updated resume download
- `backend-student-api/`: runnable Flask API learning project
- `.github/workflows/deploy.yml`: automatic GitHub Pages deployment workflow

## Publish the website
1. Create a new **public** repository on GitHub, for example `kavya-dk-portfolio`.
2. Upload the contents of this folder to the repository root (keep the `.github` folder).
3. In the repository, open **Settings → Pages** and select **GitHub Actions** as the build/deployment source.
4. Push/commit to the `main` branch. The workflow deploys the static portfolio.
5. When the workflow succeeds, open **Settings → Pages → Visit site**. The project URL will be shown there.

The website can be hosted on GitHub Pages. The Flask backend is source code and runs separately; GitHub Pages does not run Python server-side applications. Run it locally using the instructions in `backend-student-api/README.md`, or deploy it to a Python-capable host separately.

Do not upload secrets, passwords, private keys or personal documents that you do not want public. The website includes public contact details and a profile photograph.
